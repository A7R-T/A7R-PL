#!/bin/bash

# A7R-OS Deployment Script v2.0 (CachyOS Edition)
# Target: Ryzen 5 5600 + RX 6700 XT
# Identity: Authentic7Romany

set -e

echo "--- A7R-OS INITIALIZING ---"

# 1. Identity Establishment
echo "[*] Setting System Identity..."
sudo hostnamectl set-hostname A7R-OS
sudo sed -i 's/PRETTY_NAME=.*/PRETTY_NAME="A7R-OS"/' /etc/os-release
sudo sed -i 's/NAME=.*/NAME="A7R-OS"/' /etc/os-release

# 2. Package Engine (Optimized for AMD & Cachy)
echo "[*] Syncing Repositories and Installing Core Engine..."
# CachyOS should already have its repos, we just ensure the A7R stack is there.
CORE_PKGS=(
    hyprland waybar rofi-wayland kitty dolphin thunar fastfetch
    neovim git zsh ttf-jetbrains-mono-nerd otf-hermit-nerd
    grim slurp wl-clipboard pipewire wireplumber
    lib32-mesa vulkan-radeon lib32-vulkan-radeon # AMD Optimizations
    zen-browser-bin anytype-bin heroic-games-launcher-bin
    btop htop yazi nwg-look kvantum
)

sudo pacman -S --needed "${CORE_PKGS[@]}"

# 3. Restoring Soul (Dotfiles & A7R Repos)
echo "[*] Injecting A7R Soul..."
mkdir -p ~/A7R
# This assumes the user has moved the A7R folder or we are pulling from a backup
# For this script, we'll set up the links.

# Restore Zsh & P10k
cp .zshrc ~/
cp .p10k.zsh ~/

# 4. AMD RX 6700 XT Optimizations
echo "[*] Applying GPU Schedulers..."
sudo bash -c 'cat <<EOF > /etc/environment
# A7R-OS GPU ENV
XDG_SESSION_TYPE=wayland
WLR_NO_HARDWARE_CURSORS=1
AMD_VULKAN_ICD=RADV
RADV_PERFTEST=ngc
ELECTRON_OZONE_PLATFORM_HINT=wayland
EOF'

# 5. Branding Fastfetch
echo "[*] Configuring Branding..."
mkdir -p ~/.config/fastfetch
cp branding/fastfetch.jsonc ~/.config/fastfetch/config.jsonc
cp branding/A7R.txt ~/Pictures/A7R.txt

echo "--- A7R-OS ESTABLISHED ---"
echo "Reboot to finalize the Sovereign state."
